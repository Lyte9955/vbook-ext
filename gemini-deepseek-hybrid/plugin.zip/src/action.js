function execute() {
    var actions = {
        check_key_status: {
            name: "1. Kiểm tra số key & trạng thái ngữ cảnh",
            description: "Xem số lượng API key Gemini/DeepSeek đã nạp, số key đang dính RPD/RPM/403 theo model và độ dài ngữ cảnh hiện tại",
            script: "status-check.js"
        }
    };
    try {
        var book = localBook.getInfo();
        if (book && book.id) {
            actions.analyze_translation_memory = {
                name: "2. Phân tích tên nhân vật và quan hệ",
                description: "Đọc từ chương đang xem và các chương kế tiếp để cập nhật bộ nhớ dịch (tự ưu tiên DeepSeek nếu đã điền key)",
                script: "analyze-memory.js"
            };
            actions.capture_book_context = {
                name: "3. Thu thập ngữ cảnh từ chương đang mở",
                description: "Đọc chương đang mở để tạo mới story_state & cầu nối cuối chương (dùng trước khi dịch chương nhảy cóc; ưu tiên DeepSeek, giữ nguyên RPD key)",
                script: "capture-context.js"
            };
            actions.reset_book_context = {
                name: "4. Làm mới ngữ cảnh mạch truyện hiện tại",
                description: "Chỉ xóa ngữ cảnh chương trước (story_state, cầu nối chương) khi nhảy cóc chương. Giữ nguyên trạng thái RPD/cooldown của API key và bộ nhớ từ điển",
                script: "reset-context.js"
            };
        }
    } catch (e) {}
    actions.reset_key_cooldown = {
        name: "5. Gỡ cooldown API key",
        description: "Chỉ mở khóa toàn bộ trạng thái tạm nghỉ (RPD/RPM/401/403) của API key. Giữ nguyên danh sách key, ngữ cảnh truyện, bộ nhớ và prompt",
        script: "reset-keys.js"
    };
    actions.restore_defaults = {
        name: "6. Khôi phục toàn bộ cài đặt gốc",
        description: "Đặt lại toàn bộ cấu hình extension (bao gồm danh sách API key) và prompt mặc định (không xóa bộ nhớ dịch đã lưu của từng truyện)",
        script: "reset-defaults.js"
    };
    return Response.success(actions);
}
