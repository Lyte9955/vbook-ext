function execute() {
    var actions = {
        check_key_status: {
            name: "1. Kiểm tra số key & trạng thái ngữ cảnh",
            description: "Xem số lượng API key Gemini/DeepSeek đã nạp, số key đang dính RPD/RPM/403 theo model và độ dài ngữ cảnh hiện tại",
            script: "status-check.js"
        }
    };
    try {
        var book = localBook.getInfo();
        if (book && book.id) {
            actions.analyze_translation_memory = {
                name: "2. Phân tích tên nhân vật và quan hệ",
                description: "Đọc từ chương đang xem và các chương kế tiếp để cập nhật bộ nhớ dịch (tự ưu tiên DeepSeek nếu đã điền key)",
                script: "analyze-memory.js"
            };
        }
    } catch (e) {}
    actions.reset_key_cooldown = {
        name: "3. Gỡ cooldown key & làm mới ngữ cảnh truyện",
        description: "Mở khóa toàn bộ key đang tạm nghỉ và xóa ngữ cảnh chương trước (dùng khi nhảy cóc chương). Giữ nguyên API key, bộ nhớ và prompt",
        script: "reset-keys.js"
    };
    actions.restore_defaults = {
        name: "4. Khôi phục toàn bộ cài đặt gốc",
        description: "Đặt lại toàn bộ cấu hình extension (bao gồm danh sách API key) và prompt mặc định (không xóa bộ nhớ dịch đã lưu của từng truyện)",
        script: "reset-defaults.js"
    };
    return Response.success(actions);
}
