load('prompts.js');
load('llm.js');

function execute() {
    try {
        var gemKeys = llmParseApiKeys(llmReadConfig("api_key", ""));
        var dsKeys = llmReadDeepSeekKeys();
        var now = new Date().getTime();
        var state = llmLoadState(now);

        var deadAuth = 0;
        for (var fp in state.authDead) {
            if (state.authDead.hasOwnProperty(fp) && Number(state.authDead[fp]) > now) deadAuth++;
        }

        var coolingByModel = {};
        for (var bKey in state.buckets) {
            if (!state.buckets.hasOwnProperty(bKey)) continue;
            var b = state.buckets[bKey];
            if (b && b.coolUntil && Number(b.coolUntil) > now) {
                var parts = bKey.split("::");
                var mName = parts.length > 1 ? parts[1] : "unknown";
                if (!coolingByModel[mName]) coolingByModel[mName] = { rpd: 0, rpm: 0, other: 0 };
                if (b.coolReason === "rpd" || b.coolReason === "limit_zero") coolingByModel[mName].rpd++;
                else if (b.coolReason === "rpm") coolingByModel[mName].rpm++;
                else coolingByModel[mName].other++;
            }
        }

        var lines = [];
        lines.push("Gemini API keys đã nạp: " + gemKeys.length + " key (lỗi auth/403: " + deadAuth + ")");
        lines.push("DeepSeek / Gitapihub keys: " + dsKeys.length + " key");

        var hasCooling = false;
        for (var m in coolingByModel) {
            if (!coolingByModel.hasOwnProperty(m)) continue;
            hasCooling = true;
            var c = coolingByModel[m];
            lines.push("- " + m + ": " + c.rpd + " hết RPD, " + c.rpm + " chờ RPM, " + c.other + " lỗi tạm");
        }
        if (!hasCooling) lines.push("- Không có key nào đang bị cooldown.");

        try {
            var info = localBook.getInfo();
            if (info && info.id) {
                var storyState = llmLoadStoryState(String(info.id));
                var tail = llmLoadContextBridge(String(info.id));
                lines.push("Ngữ cảnh DeepSeek truyện hiện tại: " + (storyState ? storyState.length + " ký tự" : "chưa có"));
                lines.push("Cầu nối cuối chương: " + (tail ? tail.length + " ký tự" : "chưa có"));
            }
        } catch (eBook) {}

        var report = lines.join("\n");
        console.log(report);
        return Response.success(report);
    } catch (e) {
        return Response.error("Không thể kiểm tra trạng thái: " + String(e));
    }
}
