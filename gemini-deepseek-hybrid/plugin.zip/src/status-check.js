load('prompts.js');
load('llm.js');

function execute() {
    try {
        var gemKeys = llmReadGeminiKeys();
        var dsKeys = llmReadDeepSeekKeys();
        var now = new Date().getTime();
        var state = llmLoadState(now);

        var activeFps = {};
        var deadAuth = 0;
        var deadKeyNums = [];
        for (var kIdx = 0; kIdx < gemKeys.length; kIdx++) {
            var kFp = llmKeyFingerprint(gemKeys[kIdx]);
            activeFps[kFp] = true;
            if (state.authDead[kFp] && Number(state.authDead[kFp]) > now) {
                deadAuth++;
                deadKeyNums.push("#" + (kIdx + 1));
            }
        }

        var coolingByModel = {};
        for (var bKey in state.buckets) {
            if (!state.buckets.hasOwnProperty(bKey)) continue;
            var parts = bKey.split("::");
            if (!activeFps[parts[0]]) continue;
            var b = state.buckets[bKey];
            if (b && b.coolUntil && Number(b.coolUntil) > now) {
                var mName = parts.length > 1 ? parts[1] : "unknown";
                if (!coolingByModel[mName]) coolingByModel[mName] = { rpd: 0, rpm: 0, timeout: 0, other: 0 };
                if (b.coolReason === "rpd" || b.coolReason === "limit_zero") coolingByModel[mName].rpd++;
                else if (b.coolReason === "rpm") coolingByModel[mName].rpm++;
                else if (b.coolReason === "timeout") coolingByModel[mName].timeout++;
                else coolingByModel[mName].other++;
            }
        }

        var lines = [];
        lines.push("Phiên bản extension: v24");
        lines.push("Gemini API keys đã nạp: " + gemKeys.length + " key (lỗi 401/403: " + deadAuth + ")");
        if (deadKeyNums.length > 0) {
            lines.push("Vị trí key lỗi 401/403: " + deadKeyNums.join(", "));
        }
        lines.push("DeepSeek / Gitapihub keys: " + dsKeys.length + " key");

        var hasCooling = false;
        for (var m in coolingByModel) {
            if (!coolingByModel.hasOwnProperty(m)) continue;
            hasCooling = true;
            var c = coolingByModel[m];
            lines.push("- " + m + ": " + c.rpd + " hết RPD, " + c.rpm + " chờ RPM, " + c.timeout + " lỗi 504/timeout, " + c.other + " lỗi khác");
        }
        if (!hasCooling) lines.push("- Không có key nào đang bị cooldown.");
        if (state.modelDead) {
            var deadModels = [];
            for (var dm in state.modelDead) {
                if (state.modelDead.hasOwnProperty(dm) && Number(state.modelDead[dm]) > now) deadModels.push(dm);
            }
            if (deadModels.length > 0) {
                lines.push("- Model tạm bỏ qua (404): " + deadModels.join(", "));
            }
        }

        try {
            var info = localBook.getInfo();
            if (info && info.id) {
                var storyState = llmLoadStoryState(String(info.id));
                var tail = llmLoadContextBridge(String(info.id));
                lines.push("Ngữ cảnh DeepSeek truyện hiện tại: " + (storyState ? storyState.length + " ký tự" : "chưa có"));
                lines.push("Cầu nối cuối chương: " + (tail ? tail.length + " ký tự" : "chưa có"));
                var syncCnt = "";
                try { syncCnt = String(localStorage.getItem(LLM_DS_SYNC_COUNT_PREFIX + String(info.id)) || ""); } catch (eSc) {}
                if (syncCnt) lines.push("Số lượt đồng bộ DeepSeek: " + syncCnt);
            }
        } catch (eBook) {}

        if (typeof llmLoadRecentErrors === "function") {
            var recentErrors = llmLoadRecentErrors();
            if (recentErrors.length > 0) {
                lines.push("Nhật ký " + recentErrors.length + " lỗi/cứu hộ gần nhất:");
                for (var eIdx = recentErrors.length - 1; eIdx >= 0; eIdx--) {
                    var rec = recentErrors[eIdx];
                    var ageSec = Math.max(0, Math.floor((now - Number(rec.at || now)) / 1000));
                    var ageText = ageSec < 60
                        ? (ageSec + "s trước")
                        : (ageSec < 3600 ? (Math.floor(ageSec / 60) + "p trước") : (Math.floor(ageSec / 3600) + "g trước"));
                    lines.push("- [" + ageText + "][" + (rec.stage || "ERR") + "] " + (rec.detail || ""));
                }
            } else {
                lines.push("Nhật ký lỗi gần đây: không có lỗi nào.");
            }
        }

        var report = lines.join("\n");
        console.log(report);
        return Response.success(report);
    } catch (e) {
        return Response.error("Không thể kiểm tra trạng thái: " + String(e));
    }
}
