load('llm.js');

function execute() {
    try {
        llmResetKeyState();
        var bookCleared = false;
        try {
            var info = localBook.getInfo();
            if (info && info.id) {
                localStorage.removeItem(LLM_STORY_STATE_PREFIX + String(info.id));
                localStorage.removeItem(LLM_CONTEXT_BRIDGE_PREFIX + String(info.id));
                localStorage.removeItem(LLM_DS_SYNC_COUNT_PREFIX + String(info.id));
                bookCleared = true;
            }
        } catch (eBook) {}

        var msg = "Đã gỡ toàn bộ cooldown API key" +
            (bookCleared ? " và làm mới ngữ cảnh mạch truyện hiện tại" : "") +
            ". Danh sách API key, bộ nhớ từ điển và prompt vẫn được giữ nguyên.";
        console.log(msg);
        return Response.success(msg);
    } catch (e) {
        return Response.error("Không thể gỡ cooldown: " + String(e));
    }
}
