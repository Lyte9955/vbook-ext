load('baidu.js');
load('prompts.js');
load('llm.js');

var TRANSLATION_MEMORY_TABLE = "translation_memory";
var MAX_MEMORY_ROWS = 2000;
var MAX_MEMORY_MATCHES = 80;
var MAX_LEARNED_ITEMS = 20;
var MAX_CHINESE_REPAIR_FRAGMENTS = 40;
var CHINESE_FRAGMENT_CONTEXT_LENGTH = 160;
var CHAPTER_SOFT_BUDGET_MS = 55000;
var CHAPTER_HARD_BUDGET_MS = 85000;

function execute(text, from, to, source, model, style) {
    var chapterStartMs = new Date().getTime();
    text = String(text || "");
    from = String(from || "auto");
    to = String(to || "");
    source = String(source || "");
    model = llmNormalizeModel(model);
    style = String(style || "natural");

    if (!text) {
        return Response.success("");
    }
    if (!to) {
        return Response.error("Chưa chọn ngôn ngữ đích");
    }

    // Without a key the engine reports it instead of silently translating with QT/Baidu.
    var apiKeys = readApiKeys();
    if (apiKeys.length === 0 && !(typeof llmHasDeepSeek === "function" && llmHasDeepSeek())) {
        return Response.error("Vui lòng thêm " + LLM_NAME + " API key trong cài đặt extension");
    }

    if (!shouldUseProvider(source)) {
        var fallback = translateWithFallback(text, from, to, source);
        if (fallback.text) return Response.success(fallback.text);
        // Baidu does not cover every listed language; use the model instead.
    }

    // The model can hand "auto-detected" text back untranslated, while the same text with
    // an explicit source translates fine; name the detected language when it is certain.
    if (from === "auto") from = translationDetectLanguage(text) || "auto";

    var temperature = readNumber("temperature", 0.2, 0, 2);
    var maxOutputTokens = Math.round(readNumber("max_output_tokens", 16384, 256, 65536));
    var customInstruction = readBookCustomInstruction();
    var memoryContext = loadTranslationMemory(text, from, to, source);
    var bookId = memoryContext.bookId || readCurrentBookId();
    var ecoMode = readBoolean("free_tier_eco_mode", true);
    var learnMemory = !ecoMode && memoryContext.enabled && readBoolean("auto_translation_memory", false);
    var systemInstruction = buildInstruction(
        text,
        from,
        to,
        source,
        style,
        customInstruction,
        memoryContext.prompt
    );
    var contextSuffix = "";
    if (source === "chapterContent" && bookId) {
        var storyState = typeof llmLoadStoryState === "function" ? llmLoadStoryState(bookId) : "";
        var contextBridge = typeof llmLoadContextBridge === "function" ? llmLoadContextBridge(bookId) : "";
        if (storyState) {
            contextSuffix += "\n\n<story_state>\nTRẠNG THÁI MẠCH TRUYỆN & XƯNG HÔ HIỆN TẠI (chỉ dùng để bám ngữ cảnh, KHÔNG dịch lại):\n" + storyState + "\n</story_state>";
        }
        if (contextBridge) {
            contextSuffix += "\n\n<previous_tail>\nĐOẠN CUỐI CHƯƠNG TRƯỚC (chỉ dùng để nối mạch văn & giọng điệu, KHÔNG lặp lại):\n" + contextBridge + "\n</previous_tail>";
        }
        if (contextSuffix) systemInstruction += contextSuffix;
    }

    var isLineAlignedToc = source === "tableOfContent" && text.indexOf("\n") >= 0;
    var inputForModel = text;
    var tocOriginalLines = null;
    if (isLineAlignedToc) {
        tocOriginalLines = text.replace(/\r\n/g, "\n").split("\n");
        var taggedLines = [];
        for (var tl = 0; tl < tocOriginalLines.length; tl++) {
            taggedLines.push("[L" + tl + "] " + tocOriginalLines[tl]);
        }
        inputForModel = taggedLines.join("\n");
        systemInstruction += "\n\nBẮT BUỘC GIỮ ĐÚNG ĐÁNH SỐ DÒNG: giữ nguyên tiền tố [L0], [L1], ... ở đầu mỗi dòng, không gộp dòng và không thêm/bớt dòng.";
    }

    var result = requestTranslation(apiKeys, model, systemInstruction, inputForModel, temperature, maxOutputTokens, bookId, from, to, source, 55000);
    if (result.error) {
        if (typeof llmRecordError === "function") llmRecordError("TRANSLATE", result.error);
        return Response.error(result.error);
    }
    var finalText = isLineAlignedToc ? restoreLineTaggedOutput(result.text, tocOriginalLines) : result.text;

    // 1. Kiểm tra bản dịch còn nguyên văn TRƯỚC khi gọi sửa [RETRY] và sửa chữ Hán
    if (translationIsUntranslated(finalText, text, from, to)) {
        var elapsedBeforeRetry = new Date().getTime() - chapterStartMs;
        if (elapsedBeforeRetry > CHAPTER_HARD_BUDGET_MS - 15000) {
            var budgetRetryErr = LLM_NAME + " trả về bản dịch giống nguyên văn và không đủ thời gian thử lại.";
            if (typeof llmRecordError === "function") llmRecordError("RETRY", budgetRetryErr);
            return Response.error(budgetRetryErr);
        }
        var retryInstruction = buildInstruction(text, from, to, source, style, customInstruction, "") +
            contextSuffix +
            "\n\nBẮT BUỘC: dịch toàn bộ văn bản sang " + translationLanguageName(to) +
            ". Không được chép lại nguyên văn và không giữ lại câu nào bằng ngôn ngữ gốc.";
        if (isLineAlignedToc) {
            retryInstruction += "\n\nBẮT BUỘC GIỮ ĐÚNG ĐÁNH SỐ DÒNG: giữ nguyên tiền tố [L0], [L1], ... ở đầu mỗi dòng, không gộp dòng và không thêm/bớt dòng.";
        }
        var retryTimeoutMs = Math.max(15000, Math.min(55000, CHAPTER_HARD_BUDGET_MS - elapsedBeforeRetry));
        var retry = requestTranslation(apiKeys, model, retryInstruction, inputForModel, temperature, maxOutputTokens, bookId, from, to, source, retryTimeoutMs);
        if (retry.error) {
            if (typeof llmRecordError === "function") llmRecordError("RETRY", retry.error);
            return Response.error(retry.error);
        }
        finalText = isLineAlignedToc ? restoreLineTaggedOutput(retry.text, tocOriginalLines) : retry.text;
        if (translationIsUntranslated(finalText, text, from, to)) {
            var untransErr = LLM_NAME + " trả về bản dịch vẫn giống nguyên văn. Hãy thử lại hoặc đổi model.";
            if (typeof llmRecordError === "function") llmRecordError("UNTRANSLATED", untransErr);
            return Response.error(untransErr);
        }
        learnMemory = false;
    }

    // 2. Xử lý các dòng bị đánh dấu [RETRY] TRƯỚC bước sửa sót chữ Hán để tránh rò rỉ [RETRY]
    if (hasRetryMarker(finalText)) {
        var elapsedBeforeMarker = new Date().getTime() - chapterStartMs;
        var leftForMarker = CHAPTER_HARD_BUDGET_MS - elapsedBeforeMarker;
        var markerTimeout = Math.max(12000, Math.min(30000, leftForMarker));
        finalText = repairRetryMarkerLines(
            model,
            apiKeys,
            finalText,
            text,
            to,
            memoryContext.enabled ? memoryContext.prompt : "",
            maxOutputTokens,
            bookId,
            markerTimeout
        );
    }

    // 3. Sửa sót chữ Hán (luôn truyền glossary nếu đang bật bộ nhớ dịch, kể cả khi bật Eco Mode)
    var elapsedAfterMain = new Date().getTime() - chapterStartMs;
    var leftForRepair = CHAPTER_HARD_BUDGET_MS - elapsedAfterMain;
    if (shouldRepairChinese(finalText, text, from, to) && leftForRepair >= 12000) {
        var remainingHan = countChinese(finalText);
        if (elapsedAfterMain <= 60000 || remainingHan > 3) {
            var repairTimeout = Math.min(30000, leftForRepair);
            finalText = repairRemainingChinese(model, apiKeys, finalText, to, memoryContext.enabled ? memoryContext.prompt : "", maxOutputTokens, bookId, repairTimeout);
        }
    }

    if (source === "chapterContent" && bookId && typeof llmSaveContextBridge === "function") {
        llmSaveContextBridge(bookId, finalText);
    }

    // Ngân sách thời gian tổng: nếu bước dịch chính đã mất >55s hoặc chương quá ngắn (<250 ký tự) thì bỏ qua bước phụ cuối chương
    var elapsedBeforePost = new Date().getTime() - chapterStartMs;
    var allowPostSteps = elapsedBeforePost < CHAPTER_SOFT_BUDGET_MS && String(finalText || "").trim().length >= 250;

    var usedDeepSeekSync = false;
    if (allowPostSteps && source === "chapterContent" && bookId && typeof llmDeepSeekSyncContextAndMemory === "function" &&
        typeof llmHasDeepSeek === "function" && llmHasDeepSeek() && readBoolean("deepseek_context_engine", true)) {
        var sourceName = isChineseSource(text, from) ? translationLanguageName("zh") : translationLanguageName(from);
        var targetName = translationLanguageName(to);
        var syncBudgetMs = Math.max(8000, Math.min(25000, CHAPTER_HARD_BUDGET_MS - elapsedBeforePost));
        var syncRes = llmDeepSeekSyncContextAndMemory(bookId, text, finalText, sourceName, targetName, memoryContext.prompt, syncBudgetMs);
        if (syncRes && syncRes.memory && syncRes.memory.length > 0 && memoryContext.enabled) {
            persistTranslationMemory(memoryContext, text, syncRes.memory);
        }
        usedDeepSeekSync = true;
    }

    if (allowPostSteps && !usedDeepSeekSync && learnMemory) {
        var learnedItems = extractTranslationMemory(model, apiKeys, text, finalText, from, to, memoryContext.prompt, bookId);
        persistTranslationMemory(memoryContext, text, learnedItems);
    }

    return Response.success(finalText);
}

function isSuspiciouslyTruncated(translated, original, from, to, source) {
    if (source !== "chapterContent" || to !== "vi") return false;
    if (!isChineseSource(original, from)) return false;
    var hanCount = countChinese(original);
    if (hanCount < 600) return false;
    var outLen = String(translated || "").trim().length;
    // Truyện Trung -> Việt bình thường đạt ~2.5-4.5 ký tự Việt / 1 chữ Hán; dưới 1.1x là bị cụt sớm bất thường
    return outLen < Math.floor(hanCount * 1.1);
}

// Returns { text, keyIndex, error }.
function requestTranslation(apiKeys, model, systemInstruction, text, temperature, maxOutputTokens, bookId, from, to, source, timeoutMs) {
    var reqTimeout = timeoutMs || 55000;
    var result = llmRequest(
        apiKeys,
        llmBuildBody(model, systemInstruction, text, {
            temperature: temperature,
            maxTokens: maxOutputTokens,
            bookId: bookId
        }),
        reqTimeout
    );
    if (result.error) {
        if (typeof llmShouldDeepSeekRescue === "function" && llmShouldDeepSeekRescue(result.error, result.finishReason)) {
            var rescueModel = typeof llmReadConfig === "function" ? llmReadConfig("deepseek_rescue_model", "") : "";
            var rescue = llmDeepSeekRequest(
                systemInstruction,
                text,
                { temperature: temperature, maxTokens: maxOutputTokens, model: rescueModel || undefined },
                55000
            );
            if (!rescue.error && (rescue.finishReason === "length" || rescue.finishReason === "max_tokens")) {
                return {
                    text: "",
                    keyIndex: -1,
                    error: "Bản dịch cứu hộ DeepSeek bị cắt vì vượt số token đầu ra tối đa. Hãy tăng giới hạn này trong cài đặt."
                };
            }
            if (!rescue.error && rescue.text) {
                var rescuedText = sanitizeTranslationOutput(
                    parseTranslationResult(stripCodeFence(rescue.text), false).translation,
                    text
                );
                if (rescuedText) {
                    if (typeof llmRecordError === "function") {
                        llmRecordError("RESCUE", "DeepSeek cứu hộ thành công sau lỗi: " + result.error);
                    }
                    return { text: rescuedText, keyIndex: -1, error: "" };
                }
            }
            return {
                text: "",
                keyIndex: result.keyIndex,
                error: result.error + " | Cứu hộ DeepSeek thất bại: " + (rescue.error || "trả về bản dịch rỗng sau khi lọc")
            };
        }
        return { text: "", keyIndex: result.keyIndex, error: result.error };
    }
    // A cut-off chapter would be cached as a finished translation; try DeepSeek rescue (non-thinking) first!
    if (result.finishReason === "length" || result.finishReason === "max_tokens") {
        if (typeof llmShouldDeepSeekRescue === "function" && llmShouldDeepSeekRescue("max_tokens", "max_tokens")) {
            var rescueModelMt = typeof llmReadConfig === "function" ? llmReadConfig("deepseek_rescue_model", "") : "";
            var rescueMt = llmDeepSeekRequest(
                systemInstruction,
                text,
                { temperature: temperature, maxTokens: maxOutputTokens, model: rescueModelMt || undefined },
                55000
            );
            if (!rescueMt.error && rescueMt.text && rescueMt.finishReason !== "length" && rescueMt.finishReason !== "max_tokens") {
                var rescuedMtText = sanitizeTranslationOutput(
                    parseTranslationResult(stripCodeFence(rescueMt.text), false).translation,
                    text
                );
                if (rescuedMtText) return { text: rescuedMtText, keyIndex: -1, error: "" };
            }
        }
        return {
            text: "",
            keyIndex: result.keyIndex,
            error: "Bản dịch bị cắt vì vượt số token đầu ra tối đa. Hãy tăng giới hạn này hoặc giảm mức suy luận trong cài đặt."
        };
    }
    if (!result.text) {
        return {
            text: "",
            keyIndex: result.keyIndex,
            error: result.finishReason
                ? LLM_NAME + " không thể dịch: " + result.finishReason
                : LLM_NAME + " không trả về bản dịch"
        };
    }
    var translation = sanitizeTranslationOutput(
        parseTranslationResult(stripCodeFence(result.text), false).translation,
        text
    );
    if (!translation) return { text: "", keyIndex: result.keyIndex, error: LLM_NAME + " không trả về bản dịch hợp lệ" };

    // Truncation Guard: phát hiện model dừng sớm bất thường (dù finishReason là STOP) và gọi DeepSeek cứu hộ
    if (isSuspiciouslyTruncated(translation, text, from, to, source)) {
        if (typeof llmShouldDeepSeekRescue === "function" && llmShouldDeepSeekRescue("truncated", "max_tokens")) {
            var rescueModelTr = typeof llmReadConfig === "function" ? llmReadConfig("deepseek_rescue_model", "") : "";
            var rescueTr = llmDeepSeekRequest(
                systemInstruction,
                text,
                { temperature: temperature, maxTokens: maxOutputTokens, model: rescueModelTr || undefined },
                55000
            );
            if (!rescueTr.error && rescueTr.text && rescueTr.finishReason !== "length" && rescueTr.finishReason !== "max_tokens") {
                var rescuedTrText = sanitizeTranslationOutput(
                    parseTranslationResult(stripCodeFence(rescueTr.text), false).translation,
                    text
                );
                if (rescuedTrText && rescuedTrText.length > translation.length * 1.25) {
                    if (typeof llmRecordError === "function") {
                        llmRecordError("RESCUE", "Đã cứu hộ bản dịch bị cụt sớm (" + translation.length + " -> " + rescuedTrText.length + " ký tự)");
                    }
                    return { text: rescuedTrText, keyIndex: -1, error: "" };
                }
            }
        }
        // Nếu vẫn bị cụt quá nặng (<0.7x số chữ Hán), trả lỗi để vBook thử lại thay vì lưu bản dịch cụt vào cache
        if (translation.length < Math.floor(countChinese(text) * 0.7)) {
            return {
                text: "",
                keyIndex: result.keyIndex,
                error: "Bản dịch bị dừng sớm bất thường (" + translation.length + " ký tự). Vui lòng thử lại."
            };
        }
    }
    return { text: translation, keyIndex: result.keyIndex, error: "" };
}

function shouldUseProvider(source) {
    if (source === "tableOfContent") return readBoolean("translate_table_of_content", false);
    if (source === "detail") return readBoolean("translate_detail", false);
    if (source === "discovery") return readBoolean("translate_discovery", false);
    return true;
}

function translateWithFallback(text, from, to, source) {
    var qtText = "";
    if (readBoolean("use_qt_fallback", true)) {
        qtText = translateWithQt(text, from, to, source);
        // QT leaves words missing from its dictionaries in Chinese; prefer Baidu for those
        // and keep the partial QT result only if Baidu fails.
        if (qtText && !containsChinese(qtText)) {
            return { text: qtText, error: "" };
        }
    }

    var baiduResult = baiduTranslateText(text, from, to);
    if (baiduResult.text) {
        return { text: baiduResult.text, error: "" };
    }
    if (qtText) return { text: qtText, error: "" };
    return { text: "", error: baiduResult.error || "Không thể dịch bằng Baidu" };
}

function translateWithQt(text, from, to, source) {
    if (to !== "vi") return "";
    if (!isChineseSource(text, from)) return "";

    try {
        var result = Qt.translate(text, to, {
            source: source,
            chapter_name: source === "tableOfContent",
            first_line_chapter_name: source === "tableOfContent",
            first_capitalize: true
        });
        var translated = result && result.translateText ? String(result.translateText).trim() : "";
        return translated && translated !== String(text).trim() ? translated : "";
    } catch (e) {
        return "";
    }
}

function loadTranslationMemory(text, from, to, source) {
    var context = {
        enabled: false,
        bookId: "",
        prompt: "",
        existing: {},
        included: {},
        lines: []
    };

    if (!readBoolean("use_translation_memory", true)) return context;

    if (source !== "chapterContent" || !translationSourceDiffers(text, from, to)) return context;
    context.chinese = isChineseSource(text, from);
    context.to = to;

    var info;
    try {
        info = localBook.getInfo();
    } catch (e) {
        return context;
    }

    if (!info || !info.id) return context;

    context.enabled = true;
    context.bookId = String(info.id);
    translationRememberLanguages(context.bookId, from, to);

    try {
        var totalRows = localDatabase.count(context.bookId, TRANSLATION_MEMORY_TABLE);
        var rows;
        if (totalRows > MAX_MEMORY_ROWS) {
            var half = Math.floor(MAX_MEMORY_ROWS / 2);
            rows = localDatabase.list(context.bookId, TRANSLATION_MEMORY_TABLE, 0, half);
            var recentRows = localDatabase.list(
                context.bookId,
                TRANSLATION_MEMORY_TABLE,
                Math.max(0, totalRows - half),
                half
            );
            var mergedRows = [];
            for (var r1 = 0; rows && r1 < rows.length; r1++) mergedRows.push(rows[r1]);
            for (var r2 = 0; recentRows && r2 < recentRows.length; r2++) mergedRows.push(recentRows[r2]);
            rows = mergedRows;
        } else {
            rows = localDatabase.list(context.bookId, TRANSLATION_MEMORY_TABLE, 0, MAX_MEMORY_ROWS);
        }

        for (var i = 0; rows && i < rows.length; i++) {
            var rowKey = String(rows[i].key || "").trim();
            if (!rowKey) continue;
            context.existing[rowKey] = true;
            addStoredMemoryLine(context, rowKey, String(rows[i].value || ""), text);
        }

    } catch (databaseError) {}

    // The book's QT names and VietPhrases are Chinese-to-Vietnamese dictionaries.
    if (context.chinese && to === "vi") {
        try {
            addBookDictionary(context, text, localBook.getNames(), "name");
            addBookDictionary(context, text, localBook.getQtNames(), "name");
            addBookDictionary(context, text, localBook.getQtVietPhrases(), "term");
        } catch (dictionaryError) {}
    }

    if (context.lines.length > 0) {
        context.prompt = "Dùng chính xác bộ nhớ dịch riêng của truyện dưới đây; không đổi tên hoặc diễn giải lại các mục đã có:\n" +
            context.lines.join("\n");
    }

    return context;
}

function addStoredMemoryLine(context, source, rawValue, text) {
    var target = rawValue;
    var kind = "term";
    var note = "";
    var aliases = [];
    var details = [];

    try {
        var data = JSON.parse(rawValue);
        if (data && data.target) target = String(data.target);
        if (data && data.kind) kind = String(data.kind);
        if (data && data.note) note = String(data.note);
        if (data && Array.isArray(data.aliases)) aliases = data.aliases;
        if (data && data.gender && data.gender !== "unknown") details.push("giới tính: " + oneLine(data.gender));
        if (data && data.role) details.push("vai trò: " + oneLine(data.role));
        if (data && Array.isArray(data.relationships)) {
            for (var relationshipIndex = 0; relationshipIndex < data.relationships.length; relationshipIndex++) {
                var relationship = data.relationships[relationshipIndex];
                if (!relationship || !relationship["with"] || !relationship.type) continue;
                var relationshipText = oneLine(relationship["with"]) + ": " + oneLine(relationship.type);
                if (relationship.addressTo) relationshipText += ", gọi họ: " + oneLine(relationship.addressTo);
                if (relationship.addressFrom) relationshipText += ", họ gọi lại: " + oneLine(relationship.addressFrom);
                details.push("quan hệ " + relationshipText);
            }
        }
        if (data && data.autoNote) details.push(oneLine(data.autoNote));
    } catch (e) {}

    var matched = translationTermInText(text, source);
    var validAliases = [];
    for (var aliasIndex = 0; aliasIndex < aliases.length; aliasIndex++) {
        var alias = oneLine(aliases[aliasIndex]);
        if (!alias || alias === source) continue;
        validAliases.push(alias);
        if (translationTermInText(text, alias)) matched = true;
    }
    if (!matched) return;

    if (note) details.unshift(note);
    var displaySource = source;
    if (validAliases.length > 0) displaySource += " (còn gọi: " + validAliases.join(", ") + ")";
    addMemoryLine(context, displaySource, target, kind, details.join("; "));
    context.included[source] = true;
}

function addBookDictionary(context, text, dictionary, kind) {
    if (!dictionary) return;
    for (var rawKey in dictionary) {
        if (!Object.prototype.hasOwnProperty.call(dictionary, rawKey)) continue;
        var source = String(rawKey || "").trim();
        if (!source || text.indexOf(source) < 0) continue;
        addMemoryLine(context, source, String(dictionary[rawKey] || ""), kind, "");
        if (context.lines.length >= MAX_MEMORY_MATCHES) return;
    }
}

function addMemoryLine(context, source, target, kind, note) {
    if (!source || !target || context.included[source]) return;
    // A Chinese "translation" tells the model to keep the source text and snowballs into
    // fully untranslated chapters; ignore such entries, including ones already stored.
    if (containsChinese(target) && !translationWritesHan(context.to)) return;
    if (context.lines.length >= MAX_MEMORY_MATCHES) return;

    context.included[source] = true;
    var line = "- " + oneLine(source) + " => " + oneLine(target) + " [" + oneLine(kind || "term") + "]";
    if (note) line += " — " + oneLine(note);
    context.lines.push(line);
}

function parseTranslationResult(value, expectsMemory) {
    var raw = stripCodeFence(String(value || "")).trim();
    var data = parseTranslationJson(raw);
    var translation = readTranslationValue(data);

    if (translation) {
        return {
            translation: translation,
            memory: expectsMemory && Array.isArray(data.memory) ? data.memory : []
        };
    }

    var extracted = extractLooseTranslation(raw);
    if (extracted) return { translation: extracted, memory: [] };

    if (!expectsMemory && !looksLikeJsonResult(raw)) {
        return { translation: raw, memory: [] };
    }

    return { translation: "", memory: [] };
}

function parseTranslationJson(value) {
    try {
        return JSON.parse(value);
    } catch (e) {}

    var start = value.indexOf("{");
    var end = value.lastIndexOf("}");
    if (start < 0 || end <= start) return null;

    try {
        return JSON.parse(value.substring(start, end + 1));
    } catch (e2) {
        return null;
    }
}

function readTranslationValue(data) {
    if (!data || data.translation === null || data.translation === undefined) return "";
    if (typeof data.translation === "string") return data.translation;
    if (data.translation && typeof data.translation.text === "string") return data.translation.text;
    return "";
}

function extractLooseTranslation(value) {
    var memoryDelimited = value.match(/"translation"\s*:\s*"([\s\S]*)"\s*,\s*"memory"\s*:/);
    if (memoryDelimited) return decodeLooseJsonString(memoryDelimited[1]);

    var match = value.match(/"translation"\s*:\s*"((?:\\.|[^"\\])*)"/);
    return match ? decodeLooseJsonString(match[1]) : "";
}

function decodeLooseJsonString(value) {
    try {
        return String(JSON.parse('"' + value + '"'));
    } catch (e) {}

    try {
        var escapedControls = value
            .replace(/\r/g, "\\r")
            .replace(/\n/g, "\\n")
            .replace(/\t/g, "\\t");
        return String(JSON.parse('"' + escapedControls + '"'));
    } catch (e2) {}

    return String(value)
        .replace(/\\r\\n/g, "\n")
        .replace(/\\n/g, "\n")
        .replace(/\\r/g, "\n")
        .replace(/\\t/g, "\t")
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, "\\")
        .trim();
}

function looksLikeJsonResult(value) {
    var trimmed = String(value || "").trim();
    if (/"translation"\s*:/.test(trimmed)) return true;
    // Chỉ coi là JSON nếu có cấu trúc JSON thực sự ({"key": ...}), KHÔNG chặn thoại {độc thoại} hay [Thông báo hệ thống]
    if (/^\{\s*"[^"\r\n]+"\s*:/.test(trimmed)) return true;
    if (/^\[\s*\{\s*"[^"\r\n]+"\s*:/.test(trimmed)) return true;
    return false;
}

function sanitizeTranslationOutput(text, original) {
    var out = String(text || "")
        .replace(/<(think|thought|reasoning)>[\s\S]*?(?:<\/\1>|$)/gi, "")
        .replace(/<\/?(?:think|thought|reasoning)>/gi, "")
        .replace(/<(story_state|previous_tail|glossary|source_task|pronoun_rules)>[\s\S]*?(?:<\/\1>|$)/gi, "")
        .replace(/<\/?(?:story_state|previous_tail|glossary|source_task|pronoun_rules)>/gi, "")
        .trim();
    if (!out) return "";
    // Bỏ thẻ XML bọc ngoài nếu model lỡ echo lại thẻ từ XML prompt
    out = out.replace(/^\s*<(?:output|translation|result|response)[^>]*>\s*/i, "");
    out = out.replace(/\s*<\/(?:output|translation|result|response)>\s*$/i, "");
    // Xử lý ***in đậm + nghiêng*** -> giữ lại *in nghiêng* đơn
    out = out.replace(/\*\*\*([^\r\n*]+?)\*\*\*/g, "*$1*");
    // Bỏ dấu sao kép **...** nhưng giữ nguyên ký hiệu che từ ** rời rạc trong thoại
    out = out.replace(/\*\*(\S(?:(?!\*\*)[^\r\n])*?\S|\S)\*\*/g, "$1");
    // Bỏ tiêu đề Markdown (# ) ở đầu dòng nếu nguyên tác không dùng #
    if (String(original || "").indexOf("# ") < 0) {
        out = out.replace(/(^|\n)#{1,6}\s+/g, "$1");
    }
    return out.trim();
}

function persistTranslationMemory(context, input, items) {
    if (!context.bookId || !Array.isArray(items) || items.length === 0) return;

    var records = [];
    for (var i = 0; i < items.length && records.length < MAX_LEARNED_ITEMS; i++) {
        var item = items[i];
        if (!item) continue;

        var source = String(item.source || "").trim();
        var target = String(item.target || "").trim();
        if (!source || !target || context.existing[source]) continue;
        if (source.length > 80 || target.length > 160) continue;
        if (!translationIsMemoryTerm(source, target, input, context.chinese)) continue;
        if (containsChinese(target) && !translationWritesHan(context.to)) continue;

        var kind = normalizeMemoryKind(item.kind);
        var note = oneLine(String(item.note || ""));
        if (note.length > 300) note = note.substring(0, 300);

        records.push({
            key: source,
            value: JSON.stringify({ target: target, kind: kind, note: note })
        });
        context.existing[source] = true;
    }

    if (records.length === 0) return;

    try {
        localDatabase.upsertAll(context.bookId, TRANSLATION_MEMORY_TABLE, records);
    } catch (e) {}
}

function extractTranslationMemory(model, apiKeys, original, translated, from, to, memoryPrompt, bookId) {
    var sourceName = isChineseSource(original, from) ? translationLanguageName("zh") : translationLanguageName(from);
    var targetName = translationLanguageName(to);
    var instruction = "Xác định tối đa 20 tên riêng, địa danh, tổ chức, danh hiệu hoặc thuật ngữ lặp lại có độ tin cậy cao trong nguyên văn (" + sourceName + "). " +
        "Dùng đúng cách gọi tương ứng đã xuất hiện trong bản dịch (" + targetName + "). Không tự đặt tên hoặc diễn giải lại bộ nhớ hiện có. " +
        "Chỉ trả về một đối tượng JSON có mảng memory; mỗi phần tử gồm source, target, kind và note. " +
        "Mỗi source phải là chuỗi con chính xác trong NGUYÊN VĂN, viết đúng như nguyên văn. Không lấy từ thông thường. Nếu không chắc chắn thì bỏ qua mục đó.";
    if (memoryPrompt) instruction += "\n\n" + memoryPrompt;
    var userText = "NGUYÊN VĂN:\n" + original + "\n\nBẢN DỊCH:\n" + translated;

    try {
        var response = llmRequest(
            apiKeys,
            llmBuildBody(model, instruction, userText, { temperature: 0, maxTokens: 2048, json: true, bookId: bookId }),
            30000
        );
        if (response.error || !response.text) return [];
        var result = parseTranslationJson(stripCodeFence(response.text));
        return result && Array.isArray(result.memory) ? result.memory : [];
    } catch (e) {
        return [];
    }
}

function normalizeMemoryKind(value) {
    var kind = String(value || "term").toLowerCase();
    if (kind === "character" || kind === "place" || kind === "organization" || kind === "term") {
        return kind;
    }
    return "term";
}

function shouldRepairChinese(translated, original, from, to) {
    if (!readBoolean("retry_untranslated_chinese", true)) return false;
    if (translationWritesHan(to) || !isChineseSource(original, from)) return false;
    var count = countChinese(translated);
    var hasDs = typeof llmHasDeepSeek === "function" && llmHasDeepSeek();
    var minThreshold = (!hasDs && readBoolean("free_tier_eco_mode", true)) ? 4 : 1;
    if (count < minThreshold) return false;
    return true;
}

function repairRemainingChinese(model, apiKeys, draft, to, memoryPrompt, maxOutputTokens, bookId, repairTimeoutMs) {
    var previous = String(draft || "");
    var matches = previous.match(/[\u3400-\u9fff\uf900-\ufaff]+/g) || [];
    var seen = {};
    var items = [];

    for (var index = 0; index < matches.length; index++) {
        var fragment = String(matches[index] || "");
        if (!fragment || seen[fragment]) continue;
        seen[fragment] = true;
        items.push({
            id: String(items.length),
            fragment: fragment,
            context: chineseFragmentContext(previous, fragment)
        });
        if (items.length >= MAX_CHINESE_REPAIR_FRAGMENTS) break;
    }

    if (items.length === 0) return previous;

    var replacements = translateChineseFragmentsOnce(
        model,
        apiKeys,
        items,
        to,
        memoryPrompt,
        maxOutputTokens,
        bookId,
        repairTimeoutMs
    );
    if (!replacements) return previous;

    // Longest first so a short fragment never splits a longer one that contains it; a
    // fragment the model failed on stays as it was instead of discarding every fix.
    items.sort(function (a, b) { return b.fragment.length - a.fragment.length; });
    var repaired = previous;
    for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
        var item = items[itemIndex];
        var replacement = replacements[item.id];
        if (!replacement || countChinese(replacement) > 0) continue;
        repaired = replaceChineseFragment(repaired, item.fragment, replacement);
    }
    return repaired;
}

// Chinese needs no spaces, so "Hoàng玉" must become "Hoàng Ngọc", not "HoàngNgọc".
function replaceChineseFragment(text, fragment, replacement) {
    var parts = text.split(fragment);
    var result = parts[0];
    for (var i = 1; i < parts.length; i++) {
        var before = result.charAt(result.length - 1);
        var after = parts[i].charAt(0);
        var value = replacement;
        if (/[0-9A-Za-z\u00c0-\u024f\u1e00-\u1eff]/.test(before)) value = " " + value;
        if (/[0-9A-Za-z\u00c0-\u024f\u1e00-\u1eff]/.test(after)) value += " ";
        result += value + parts[i];
    }
    return result;
}

function chineseFragmentContext(text, fragment) {
    var value = String(text || "");
    var position = value.indexOf(fragment);
    if (position < 0) return fragment;
    var start = Math.max(0, position - CHINESE_FRAGMENT_CONTEXT_LENGTH);
    var end = Math.min(value.length, position + fragment.length + CHINESE_FRAGMENT_CONTEXT_LENGTH);
    return value.substring(start, end);
}

function translateChineseFragmentsOnce(model, apiKeys, items, to, memoryPrompt, maxOutputTokens, bookId, repairTimeoutMs) {
    var instruction = "Dịch mọi cụm tiếng Trung được cung cấp sang " + translationLanguageName(to) + " tự nhiên để chèn vào bản dịch văn học hiện có. " +
        "Chỉ dùng ngữ cảnh của từng mục để xác định nghĩa, tên riêng và cách xưng hô; không dịch hoặc trả lại phần ngữ cảnh. " +
        "Chỉ trả về một đối tượng JSON hợp lệ, không dùng Markdown, theo đúng cấu trúc: " +
        '{"items":[{"id":"0","translation":"phần thay thế đã dịch"}]}. ' +
        "Trả về mỗi id đầu vào đúng một lần. Mỗi translation chỉ được chứa phần thay thế cho cụm tương ứng.";
    if (memoryPrompt) instruction += "\n\n" + memoryPrompt;

    try {
        var response;
        if (typeof llmHasDeepSeek === "function" && llmHasDeepSeek()) {
            response = llmDeepSeekRequest(
                instruction,
                JSON.stringify({ items: items }),
                { temperature: 0, maxTokens: Math.min(maxOutputTokens || 4096, 4096), json: true },
                repairTimeoutMs || 30000
            );
        } else {
            response = llmRequest(
                apiKeys,
                llmBuildBody(model, instruction, JSON.stringify({ items: items }), {
                    temperature: 0,
                    maxTokens: Math.min(maxOutputTokens || 4096, 4096),
                    json: true,
                    bookId: bookId
                }),
                repairTimeoutMs || 30000
            );
        }
        if (response.error) return null;

        var output = stripCodeFence(response.text).trim();
        if (!output) return null;

        var parsed = parseTranslationJson(output);
        if (!parsed || !Array.isArray(parsed.items)) return null;

        var replacements = {};
        for (var index = 0; index < parsed.items.length; index++) {
            var translatedItem = parsed.items[index];
            if (!translatedItem || translatedItem.id === undefined) continue;
            var id = String(translatedItem.id);
            var translation = String(translatedItem.translation || "").trim();
            if (translation) replacements[id] = translation;
        }
        return replacements;
    } catch (e) {
        return null;
    }
}

function containsChinese(value) {
    return /[\u3400-\u9fff\uf900-\ufaff]/.test(String(value || ""));
}

function countChinese(value) {
    var matches = String(value || "").match(/[\u3400-\u9fff\uf900-\ufaff]/g);
    return matches ? matches.length : 0;
}

function oneLine(value) {
    return String(value || "").replace(/[\r\n\t]+/g, " ").trim();
}

function isChineseSource(text, from) {
    return translationIsChineseSource(text, from);
}

function readConfig(key, fallback) {
    try {
        var value = localConfig.getItem(translationConfigKey(key));
        if (value === null || value === undefined) return fallback;
        var text = String(value);
        return text.trim() === "" ? fallback : text;
    } catch (e) {
        return fallback;
    }
}

function readCurrentBookId() {
    try {
        var info = localBook.getInfo();
        if (info && info.id) return String(info.id);
    } catch (e) {}
    return "";
}

function readBookCustomInstruction() {
    try {
        var info = localBook.getInfo();
        if (info && info.id) {
            var key = translationBookPromptConfigKey(String(info.id));
            return readConfig(key, "").trim();
        }
    } catch (e) {}
    return "";
}

function readBoolean(key, fallback) {
    return readConfig(key, fallback ? "true" : "false") === "true";
}

function readApiKeys() {
    return llmReadGeminiKeys();
}


function readNumber(key, fallback, min, max) {
    var value = parseFloat(readConfig(key, String(fallback)));
    if (isNaN(value)) value = fallback;
    if (value < min) value = min;
    if (value > max) value = max;
    return value;
}


function buildInstruction(text, from, to, source, style, customInstruction, memoryPrompt) {
    var chineseSource = isChineseSource(text, from);
    var sourceLanguage = translationLanguageName(from);
    var targetLanguage = translationLanguageName(to);
    // Genre styles are written for Vietnamese output; the generic style fits any target.
    var styleId = translationResolveStyle(style, chineseSource);
    var stylePrompt = to === "vi" || styleId === "tu-nhien" ? loadTranslationStylePrompt(styleId) : "";
    if (stylePrompt) {
        stylePrompt = stylePrompt.split("{target_language}").join(targetLanguage);
        var note = translationNonChineseNote(chineseSource);
        if (note) stylePrompt += "\n" + note;
    }
    var sourcePrompt = "";
    if (source === "chapterContent") {
        sourcePrompt = "Viết văn xuôi trôi chảy, phù hợp với một chương truyện.";
    } else if (source === "tableOfContent") {
        sourcePrompt = "Giữ nguyên số thứ tự chương và dịch tiêu đề ngắn gọn.";
    } else if (source === "detail") {
        sourcePrompt = "Giữ nguyên các nhãn thông tin và mọi cấu trúc HTML.";
    } else if (source === "discovery") {
        sourcePrompt = "Dịch tiêu đề, thẻ và mô tả ngắn một cách súc tích.";
    }
    var isStandaloneCustomPrompt = customInstruction &&
        (/^\s*<prompt[\s>]/i.test(customInstruction) || /<\/(?:prompt|role|instructions|constraints)>/i.test(customInstruction));

    var template;
    if (isStandaloneCustomPrompt) {
        // Khi người dùng dán full XML prompt vào "Yêu cầu dịch riêng cho truyện":
        // Dùng trực tiếp prompt đó cho RIÊNG truyện này, bỏ qua system_prompt & style mặc định để tránh xung đột luật và tiết kiệm token.
        template = customInstruction;
        if (sourcePrompt && template.indexOf("{source_prompt}") < 0) {
            template += "\n\n<source_task>" + sourcePrompt + "</source_task>";
        }
        if (memoryPrompt && template.indexOf("{memory_prompt}") < 0) {
            template += "\n\n<glossary>\n" + memoryPrompt + "\n</glossary>";
        }
    } else {
        template = readConfig("system_prompt", translationDefaultSystemPrompt());
        // Bảo đảm không bao giờ mất bộ nhớ dịch nếu người dùng sửa system_prompt mà quên biến {memory_prompt}
        if (memoryPrompt && template.indexOf("{memory_prompt}") < 0) {
            template += "\n\n" + memoryPrompt;
        }
    }

    var values = {
        source_language: sourceLanguage,
        target_language: targetLanguage,
        style_prompt: stylePrompt ? "PHONG CÁCH DỊCH TRUYỆN:\n" + stylePrompt : "",
        source_prompt: sourcePrompt,
        custom_instruction: (!isStandaloneCustomPrompt && customInstruction) ? "YÊU CẦU RIÊNG:\n" + customInstruction : "",
        memory_prompt: memoryPrompt || ""
    };
    for (var key in values) {
        if (values.hasOwnProperty(key)) {
            template = template.split("{" + key + "}").join(values[key]);
        }
    }
    // Appended outside the editable template so customized system prompts get it too.
    if (translationSourceDiffers(text, from, to)) {
        template += "\n\nBẮT BUỘC VỀ NGÔN NGỮ: mọi câu trong bản dịch phải viết bằng " + targetLanguage +
            ", kể cả tiêu đề, lời tác giả, lời nhắn, quảng cáo, ghi chú và thông báo hệ thống. ";
        if (chineseSource && !translationWritesHan(to)) {
            template += "Không để sót bất kỳ chữ Hán nào; tên riêng và thuật ngữ chưa có trong bộ nhớ thì " +
                (to === "vi" ? "phiên âm Hán Việt. " : "phiên âm theo quy ước phổ biến của " + targetLanguage + ". ");
        } else {
            template += "Không để sót câu hoặc cụm từ nào bằng ngôn ngữ gốc. ";
        }
        template += "Không chèn nguyên văn hoặc chú thích trong ngoặc.";
        if (chineseSource && to === "vi" && !isStandaloneCustomPrompt && source === "chapterContent") {
            var pronounBlock = "<pronoun_rules>\n" +
                "KHÓA CỨNG ĐẠI TỪ NHÂN XƯNG TRUNG VĂN (ƯU TIÊN CAO NHẤT — ÁP DỤNG MỌI PHONG CÁCH):\n" +
                "1) Ngôi kể thứ ba: nam dùng thống nhất hắn (hoặc y/gã/lão tùy sắc thái), nữ dùng nàng hoặc cô (tùy bối cảnh). CẤM TUYỆT ĐỐI: anh ấy, anh ta, cậu ấy, cậu ta, cô ấy, cô ta, chị ấy, ông ấy, anh chàng, cô nàng.\n" +
                "2) Đối thoại (KHÓA CỨNG TA - NGƯƠI): Mọi đại từ 我 / 你 trong nguyên văn tiếng Trung ĐỀU dịch thống nhất là ta - ngươi (và ta - ngài / tại hạ - các hạ / vãn bối - tiền bối khi nguyên văn có kính ngữ). CẤM TUYỆT ĐỐI dùng đại từ Việt Nam (tôi, tớ, cậu, anh/em, chị/em, chú/cháu, bác/cháu, tao/mày, em/thầy) để tránh hoàn toàn lỗi sai giới tính và sai vai vế — trừ khi nguyên văn gọi thẳng danh xưng ruột thịt/quan hệ (ca, tỷ, phụ thân, mẫu thân, lão sư, sư phụ...).\n" +
                "3) Danh xưng Trung ngữ: giữ nguyên trật tự [Họ/Tên + hậu tố/chức vị] và viết thường hậu tố (Lâm ca, Phùng lão sư, Trương đội, Vương tổng, Tô sư tỷ); KHÔNG đảo thành anh Lâm, thầy Phùng, đội trưởng Trương.\n" +
                "4) Nhất quán tuyệt đối xuyên suốt chương và bám sát <story_state> + <glossary>.\n" +
                "</pronoun_rules>";
            template = pronounBlock + "\n\n" + template;
        }
    }
    return String(template).replace(/\n{3,}/g, "\n\n").trim();
}

function loadTranslationStylePrompt(style) {
    var selected = String(style || "");
    try {
        var stored = localDatabase.get(TRANSLATION_PROMPT_SCOPE, TRANSLATION_PROMPT_TABLE, selected);
        if (stored !== null && stored !== undefined) {
            return String(stored).trim();
        }
    } catch (e) {}
    var prompts = translationDefaultPrompts();
    return prompts[selected] || prompts["tu-nhien"];
}



function stripCodeFence(text) {
    var value = String(text || "").trim();
    var exact = value.match(/^```[^\n]*\n([\s\S]*?)\n```$/);
    if (exact) return exact[1];
    var embedded = value.match(/```[^\n]*\n([\s\S]*?)\n```/);
    return embedded ? embedded[1] : value;
}

function restoreLineTaggedOutput(output, originalLines) {
    var lines = String(output || "").replace(/\r\n/g, "\n").split("\n");
    var mapped = {};
    var matchedCount = 0;
    for (var i = 0; i < lines.length; i++) {
        var m = lines[i].match(/^\s*\[L(\d+)\]\s*(.*)$/);
        if (m) {
            var idx = parseInt(m[1], 10);
            if (!isNaN(idx) && idx >= 0 && idx < originalLines.length) {
                mapped[idx] = m[2];
                matchedCount++;
            }
        }
    }
    if (matchedCount > 0) {
        var result = [];
        for (var j = 0; j < originalLines.length; j++) {
            result.push(mapped[j] !== undefined ? mapped[j] : originalLines[j]);
        }
        return result.join("\n");
    }
    // Fallback: xóa tag [L\d+] nếu có
    var cleaned = [];
    for (var k = 0; k < lines.length; k++) {
        cleaned.push(lines[k].replace(/^\s*\[L\d+\]\s*/, ""));
    }
    return cleaned.join("\n");
}

function hasRetryMarker(text) {
    return /(?:\[|\u3010)\s*RETRY\s*(?:\]|\u3011)/i.test(String(text || ""));
}

function repairRetryMarkerLines(model, apiKeys, draft, original, to, memoryPrompt, maxOutputTokens, bookId, timeoutMs) {
    var outLines = String(draft || "").replace(/\r\n/g, "\n").split("\n");
    var srcLines = String(original || "").replace(/\r\n/g, "\n").split("\n");
    var sameCount = outLines.length === srcLines.length;

    var retryItems = [];
    for (var i = 0; i < outLines.length; i++) {
        if (!hasRetryMarker(outLines[i])) continue;
        var srcLine = sameCount ? String(srcLines[i] || "").trim() : "";
        if (!srcLine && i < srcLines.length) srcLine = String(srcLines[i] || "").trim();
        var prevLine = i > 0 ? outLines[i - 1] : "";
        var nextLine = i + 1 < outLines.length ? outLines[i + 1] : "";
        retryItems.push({
            id: String(i),
            lineIndex: i,
            source: srcLine,
            before: prevLine,
            after: nextLine
        });
    }
    if (retryItems.length === 0) return draft;

    var instruction = "Các dòng dưới đây trong bản dịch trước bị đánh dấu lỗi [RETRY]. " +
        "Hãy dịch chính xác trường source sang " + translationLanguageName(to) + " khớp mạch văn với before và after. " +
        "Chỉ trả về DUY NHẤT một đối tượng JSON hợp lệ (không Markdown): " +
        '{"items":[{"id":"0","translation":"dòng đã dịch hoàn chỉnh"}]}. ' +
        "Không được chứa [RETRY] và không để sót chữ Hán.";
    if (memoryPrompt) instruction += "\n\n" + memoryPrompt;

    var replacements = null;
    try {
        var response;
        if (typeof llmHasDeepSeek === "function" && llmHasDeepSeek()) {
            response = llmDeepSeekRequest(
                instruction,
                JSON.stringify({ items: retryItems }),
                { temperature: 0.1, maxTokens: Math.min(maxOutputTokens || 4096, 4096), json: true },
                timeoutMs || 25000
            );
        } else {
            response = llmRequest(
                apiKeys,
                llmBuildBody(model, instruction, JSON.stringify({ items: retryItems }), {
                    temperature: 0.1,
                    maxTokens: Math.min(maxOutputTokens || 4096, 4096),
                    json: true,
                    bookId: bookId
                }),
                timeoutMs || 25000
            );
        }
        if (response && !response.error && response.text) {
            var parsed = parseTranslationJson(stripCodeFence(response.text));
            if (parsed && Array.isArray(parsed.items)) {
                replacements = {};
                for (var p = 0; p < parsed.items.length; p++) {
                    var it = parsed.items[p];
                    if (it && it.id !== undefined && it.translation) {
                        var tr = sanitizeTranslationOutput(String(it.translation), "").replace(/(?:\[|\u3010)\s*RETRY\s*(?:\]|\u3011)/gi, "").trim();
                        if (tr) replacements[String(it.id)] = tr;
                    }
                }
            }
        }
    } catch (e) {}

    for (var r = 0; r < retryItems.length; r++) {
        var item = retryItems[r];
        var rep = replacements ? replacements[item.id] : "";
        if (rep) {
            outLines[item.lineIndex] = rep;
        } else {
            // Chặn rò rỉ [RETRY] tuyệt đối: gỡ marker hoặc dùng dòng nguồn để bước sửa Hán tự xử lý tiếp
            var stripped = outLines[item.lineIndex].replace(/(?:\[|\u3010)\s*RETRY\s*(?:\]|\u3011)/gi, "").trim();
            outLines[item.lineIndex] = stripped || item.source || "";
        }
    }
    return outLines.join("\n");
}
